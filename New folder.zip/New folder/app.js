'use strict';
(() => {
/* =====================================================================
   Daily Planner. Everything lives in one state object (S).
   Storage is local for now. To add cloud sync later, fill in Sync.push()
   and Sync.pull() below; nothing else needs to change.
   ===================================================================== */

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const pad = n => String(n).padStart(2, '0');
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KEY = 'enon-planner-v4';
const dayKey = () => { const d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };

/* ---------- starter data ---------- */
const PALS = [['Blush','#C2447A','#9AD9C3','#F7C6D9'],['Lilac','#7E57C2','#F4B6D2','#D9CCF5'],['Rose','#B83B5E','#B5D8F0','#FAD1DF'],['Cherry','#C0264B','#BFE3D0','#FBD0D8'],['Peony','#A12B7A','#A8DCD5','#F3C7E6']];
const RAW = [[0,'Ideal properties'],[60,'Geometrical properties'],[180,'Physiology: Energy, work'],[240,'Sleep',1],[510,'Breakfast',1],[540,'Physiology: Energy pt. 2'],[600,'Question solve'],[690,'Rheumatology'],[720,'Bones, thalassemia'],[780,'Hemophilia'],[840,'Question solve'],[900,'Exam'],[960,'Exam'],[980,'Shower + lunch'],[1020,'Acid base: Human pH'],[1080,'Geometric properties'],[1140,'Notes'],[1200,'Cardio, 30 min',1],[1245,'Dinner',1],[1290,'Free time',1],[1320,'Tissue'],[1439,'Reproduction']];
const SUBJ = [['Anatomy',['Upper Limb','Lower Limb','Thorax','Abdomen','Pelvis and Perineum','Head and Neck','Neuroanatomy','Embryology','Genetics']],['Histology',['Cell and Cytoplasm','Epithelium','Connective Tissue','Cartilage and Bone','Muscle Tissue','Nervous Tissue','Blood and Lymphoid','Cardiovascular System','Respiratory System','Digestive System','Urinary System','Endocrine System','Reproductive System','Skin and Special Senses']],['Physiology',['General Physiology','Nerve and Muscle','Blood','Cardiovascular','Respiratory','Renal and Body Fluids','Acid-Base Balance','Gastrointestinal','Endocrine','Reproduction','Nervous System','Special Senses','Energy, Work and Metabolism']],['Biochemistry',['Cell and Biomolecules','Carbohydrates','Lipids','Amino Acids and Proteins','Enzymes','Vitamins and Minerals','Nucleic Acids and Molecular Biology','Carbohydrate Metabolism','Lipid Metabolism','Protein Metabolism','Heme and Hemoglobin','Bioenergetics','Clinical Biochemistry']]];
const SC = ['#C2447A','#8A63D2','#2F9E8F','#D9779B','#5A8FD6','#B7791F'];
const LBL = ['Not started','In progress','Revised'];
const MOODS = ['Low','Okay','Good','Great','Amazing'];
const PRAYERS = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
const mkSubj = () => SUBJ.map((x, i) => ({id:'u'+i, n:x[0], ch:x[1].map((c, j) => ({id:'c'+i+'_'+j, n:c, s:0}))}));
const def = () => ({
  v:4, subj:mkSubj(), sel:'u0',
  sched:RAW.map((x, i) => ({id:'s'+i, m:x[0], l:x[1], a:x[2] || 0})),
  done:{}, water:0, goal:8, pr:[0,0,0,0,0], habs:[{n:'Cardio, 30 minutes', d:0}], screen:0,
  todos:[{t:'Rewatching Mean Girls', d:0},{t:'Finish reading How to Leave a Guy in 10 Days', d:0},{t:'Current affairs + MP3', d:0}],
  pri:['Quest bank solve','Prev year suggestion','Topic based',''],
  win:'', mood:-1, tom:'', carry:'', view:'timeline', tab:'today',
  notes:['Drink lots of water','Pray 5x','Less screen time','Cardio every day','Live the life','Active recall beats rereading','Short break every 90 minutes','Eat before you study','One question bank block a day','Review yesterday before new topics','Slow days still count','Be proud of every small win'],
  script:'Praying to add a DR. soon',
  name:"Enon's", head:'Daily Planner', g1:'Hi, Miss Doctor.', g2:'Here you go, your daily planner.',
  pal:0, acc:'', seen:0, always:0, day:'', gal:[], img:{},
  focusToday:0, tcfg:{f:25, b:5}, timer:null, history:[], presets:[], week:{}
});

let S = def();
try { const raw = JSON.parse(localStorage.getItem(KEY) || 'null'); if (raw && typeof raw === 'object') S = Object.assign(def(), raw); } catch (e) {}
S.tcfg = Object.assign({f:25, b:5}, S.tcfg);

/* ---------- saving + sync hook ---------- */
const Sync = {
  push(state) { /* cloud sync goes here later: send `state` to the server */ },
  pull() { /* and fetch the latest state here */ }
};
let pt;
const persist = () => { clearTimeout(pt); pt = setTimeout(flush, 250); };
function flush() {
  clearTimeout(pt);
  S.timer = {mode:T.mode, left:T.left, end:T.end, run:T.run};
  try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {}
  try { Sync.push(S); } catch (e) {}
}
addEventListener('pagehide', flush);

/* ---------- helpers ---------- */
const f = m => { m %= 1440; const h = Math.floor(m / 60); return (h % 12 || 12) + ':' + pad(m % 60) + ' ' + (h < 12 ? 'AM' : 'PM'); };
const hh = m => pad(Math.floor(Math.min(m, 1439) / 60)) + ':' + pad(Math.min(m, 1439) % 60);
const schedFor = d => S.sched.filter(s => !s.only || s.only === d);
const SS = () => schedFor(S.day).sort((a, b) => a.m - b.m);
const cur = () => { const n = new Date(), m = n.getHours() * 60 + n.getMinutes(); let k = 0; SS().forEach((s, i) => { if (s.m <= m) k = i; }); return k; };
const doneCount = () => SS().filter(s => S.done[s.id]).length;
const find = id => { for (const x of S.subj) { const c = x.ch.find(y => y.id === id); if (c) return [x, c]; } return []; };
const EDIT = {};

const CK = '<span class="ck"><svg viewBox="0 0 24 24"><path d="M12 19.500s-6.500-4.100-6.500-9a3.800 3.800 0 0 1 6.500-2.500 3.800 3.800 0 0 1 6.500 2.500c0 4.900-6.500 9-6.500 9z"/></svg></span>';
const CHK = '<svg viewBox="0 0 24 24"><path d="M5 12.500l4.500 4.500L19 7.500"/></svg>';


/* ---------- plans (presets) ---------- */
const TPL = {
  full:[[420,'Wake up + water',1],[450,'Breakfast',1],[510,'@1'],[630,'Short break',1],[645,'@2'],[765,'@q'],[810,'Lunch + rest',1],[870,'@3'],[990,'@r'],[1050,'Cardio, 30 min',1],[1110,'Free time',1],[1170,'@s'],[1230,'Dinner',1],[1290,'Review today + plan tomorrow'],[1350,'Wind down',1],[1380,'Sleep',1]],
  light:[[480,'Wake up + water',1],[510,'Breakfast',1],[600,'@1'],[720,'Walk + lunch',1],[840,'@r'],[1020,'Cardio, 30 min',1],[1110,'Free time',1],[1230,'Dinner',1],[1320,'Wind down',1],[1380,'Sleep',1]],
  rest:[[540,'Wake up slowly',1],[570,'Breakfast',1],[660,'Something you love',1],[780,'Lunch',1],[900,'Walk or cardio',1],[1080,'Free time',1],[1230,'Dinner',1],[1290,'Plan tomorrow'],[1380,'Sleep',1]],
  exam:[[360,'Wake up + breakfast',1],[420,'Quick revision'],[480,'Exam'],[720,'Lunch + rest',1],[780,'Light review'],[1050,'Cardio, 30 min',1],[1230,'Dinner',1],[1380,'Sleep',1]]
};
const chaps = x => x.ch.filter(c => c.s !== 2).sort((a, b) => b.s - a.s);
const chLabel = (x, k) => { const c = chaps(x)[k]; return x.n + ': ' + (c ? c.n : 'revision'); };
function mk(tpl, o) {
  return TPL[tpl].map(t => {
    const c = t[1]; let l = c;
    if (c === '@1' || c === '@2' || c === '@3') l = o.blk(+c[1] - 1);
    else if (c === '@q') l = o.q; else if (c === '@r') l = o.r; else if (c === '@s') l = o.s;
    return {m:t[0], l, a:t[2] || 0};
  });
}
function builtIns() {
  const L = [];
  S.subj.forEach(x => L.push({id:'b:' + x.id, n:x.n + ' day', d:'Study blocks on ' + x.n + ', questions and revision', items:() => mk('full', {blk:k => chLabel(x, k), q:x.n + ': question solve', r:'Revise ' + x.n, s:x.n + ': recap + flashcards'})}));
  if (S.subj.length > 1) L.push({id:'b:mix', n:'Mixed day', d:'A different subject in each block', items:() => mk('full', {blk:k => chLabel(S.subj[k % S.subj.length], 0), q:'Question solve, mixed', r:"Revise today's topics", s:'Recap + flashcards'})});
  L.push({id:'b:qb', n:'Question bank day', d:'Mostly practice questions', items:() => mk('full', {blk:k => ['Quest bank solve', 'Prev year suggestion', 'Topic based questions'][k], q:'Review the mistakes', r:'Notes on weak topics', s:'Quest bank solve'})});
  L.push({id:'b:rev', n:'Revision day', d:'Go back over chapters you started', items:() => { const w = S.subj.flatMap(x => x.ch.filter(c => c.s === 1).map(c => x.n + ': ' + c.n)); return mk('full', {blk:k => 'Revise ' + (w[k] || 'your notes'), q:'Question solve on revised topics', r:'Make short notes', s:'Recap + flashcards'}); }});
  L.push({id:'b:light', n:'Light day', d:'One study block, plenty of rest', items:() => mk('light', {blk:k => chLabel(S.subj[0] || {n:'Study', ch:[]}, k), r:'Revise a little'})});
  L.push({id:'b:exam', n:'Exam day', d:'Quick revision, exam, rest', items:() => mk('exam', {})});
  L.push({id:'b:rest', n:'Rest day', d:'Sleep, meals, free time', items:() => mk('rest', {})});
  L.push({id:'b:start', n:'Starter plan', d:'The original schedule', items:() => RAW.map(x => ({m:x[0], l:x[1], a:x[2] || 0}))});
  return L;
}
const allPlans = () => builtIns().concat(S.presets.map(p => ({id:p.id, n:p.n, d:p.items.length + ' items', mine:1, items:() => p.items.map(x => ({m:x.m, l:x.l, a:x.a || 0}))})));
const planById = id => allPlans().find(p => p.id === id);
const fresh = items => items.map((x, i) => ({id:'s' + Date.now().toString(36) + i, m:x.m, l:x.l, a:x.a || 0})).sort((a, b) => a.m - b.m);

/* ---------- day rollover ---------- */
function checkDay() {
  const k = dayKey();
  if (S.day === k) return false;
  if (S.day) {
    const L = schedFor(S.day);
    S.history.push({d:S.day, done:L.filter(s => S.done[s.id]).length, total:L.length, water:S.water, pr:S.pr.filter(Boolean).length, habs:S.habs.filter(h => h.d).length, screen:S.screen, mood:S.mood, win:S.win, focus:S.focusToday});
    S.history = S.history.slice(-120);
    if (S.tom.trim()) { S.carry = S.tom.trim(); S.tom = ''; }
  }
  S.done = {}; S.water = 0; S.pr = [0,0,0,0,0]; S.habs.forEach(h => h.d = 0); S.screen = 0; S.win = ''; S.mood = -1; S.focusToday = 0;
  S.todos = S.todos.filter(t => !t.d);
  S.sched = S.sched.filter(s => !s.only || s.only >= k);
  S.day = k;
  const wp = S.week[new Date().getDay()], pl = wp && planById(wp);
  if (pl) S.sched = fresh(pl.items());
  persist();
  return true;
}
checkDay();

/* =====================================================================
   Skeleton buddy
   ===================================================================== */
/* Desk scene: a girl skeleton reads at her desk; a boy skeleton visits when she completes something. */
const SK = (() => {
const B = (d, w = 8) => `<path class="bo" stroke-width="${w}" d="${d}"/><path class="bi" stroke-width="${w - 3}" d="${d}"/>`;
const JT = (x, y, r = 5) => `<circle class="jt" cx="${x}" cy="${y}" r="${r}"/>`;
const HT = 'M0 6 C-9 0 -7 -8 0 -4 C7 -8 9 0 0 6Z';
const STR = 'M0 -8 L2.200 -2.200 L8 0 L2.200 2.200 L0 8 L-2.200 2.200 L-8 0 L-2.200 -2.200Z';
const handArt = fo => `<ellipse class="sh" cx="0" cy="${fo + 6}" rx="5.500" ry="6.500"/>` + B(`M-3 ${fo + 10} L-4 ${fo + 16}`, 4.500) + B(`M0 ${fo + 11} L0 ${fo + 18}`, 4.500) + B(`M3 ${fo + 10} L4 ${fo + 16}`, 4.500);
const FLOWER = fo => `<g class="fw"><path d="M0 ${fo + 8} L0 ${fo + 30}" class="stem"/>` + [0, 72, 144, 216, 288].map(a => `<ellipse class="pt" cx="0" cy="${fo + 38}" rx="4" ry="6" transform="rotate(${a} 0 ${fo + 38}) translate(0 -5)"/>`).join('') + `<circle class="pc" cx="0" cy="${fo + 38}" r="3.200"/></g>`;
const arm = (x, p, s, up, fo, extra = '') => `<g transform="translate(${x} 114)"><g class="j" data-j="${p}a${s}">${B(`M0 0 L0 ${up}`, 8)}${JT(0, 0, 5.500)}<g transform="translate(0 ${up})"><g class="j" data-j="${p}f${s}"><g class="wob wob${s}">${B(`M0 0 L0 ${fo}`, 7)}${JT(0, 0, 4.500)}${handArt(fo)}${extra}</g></g></g></g></g>`;
const torso = (rw, sx) => [0, 1, 2, 3].map(i => `<rect class="vt" x="-3" y="${110 + i * 9}" width="6" height="7" rx="3"/>`).join('')
  + [0, 1, 2].map(i => { const y = 117 + i * 9; return B(`M-2 ${y} Q${-rw} ${y - 4} ${-rw + 2} ${y + 10}`, 5.500) + B(`M2 ${y} Q${rw} ${y - 4} ${rw - 2} ${y + 10}`, 5.500); }).join('')
  + B(`M-2 111 Q${-sx / 2} 107 ${-sx} 114`, 5) + B(`M2 111 Q${sx / 2} 107 ${sx} 114`, 5);
const face = boy => `<g transform="translate(0 -100)"><g class="hb">
 <path class="sh" d="M-24 84 Q-22 105 0 107 Q22 105 24 84Z"/>
 <ellipse class="sh" cx="0" cy="72" rx="${boy ? 32 : 31}" ry="28.500"/>
 <ellipse class="bl" cx="-21" cy="87" rx="7" ry="4"/><ellipse class="bl" cx="21" cy="87" rx="7" ry="4"/>
 <g class="eyes"><ellipse class="eye" cx="-12" cy="76" rx="${boy ? 7.500 : 8.500}" ry="${boy ? 9.500 : 10}"/><ellipse class="eye" cx="12" cy="76" rx="${boy ? 7.500 : 8.500}" ry="${boy ? 9.500 : 10}"/>
 <circle fill="#fff" cx="-14.500" cy="72" r="3.200"/><circle fill="#fff" cx="9.500" cy="72" r="3.200"/><circle fill="#fff" cx="-9" cy="81" r="1.500"/><circle fill="#fff" cx="15" cy="81" r="1.500"/>
 ${boy ? '<path class="lash" d="M-19 62 Q-12 57 -5 61 M5 61 Q12 57 19 62"/>' : '<path class="lash" d="M-20 69 L-26 65 M-21 75 L-27 74 M20 69 L26 65 M21 75 L27 74"/>'}</g>
 <path class="shut" d="M-20 78 Q-12 69 -4 78 M4 78 Q12 69 20 78"/>
 <path class="nose" d="M0 90 L-3 85 Q-1 82 0 84 Q1 82 3 85Z"/>
 <path class="te" d="M-13 97 Q0 102 13 97 L11 101 Q0 106 -11 101Z"/><path class="tk" d="M-6 99 L-6 103 M0 100 L0 104 M6 99 L6 103"/>
 <ellipse class="gape" cx="0" cy="99" rx="8" ry="5"/>
 ${boy ? '<path class="hair" d="M-14 46 Q-6 26 10 38 Q16 34 16 46 Q4 38 -14 46Z"/>' : '<g class="bow"><path d="M19 47 C26 32 44 36 41 50 C39 58 27 58 19 47Z"/><path d="M19 47 C14 34 2 34 5 46 C7 54 14 54 19 47Z"/><circle cx="20" cy="47" r="5"/></g>'}
</g></g>`;

function scene() {
  const lights = [[22, 24], [58, 31], [98, 26], [140, 21], [182, 25], [222, 22], [262, 23], [300, 16]].map((p, i) => `<circle class="bulb b${i % 3}" cx="${p[0]}" cy="${p[1]}" r="3.200"/>`).join('');
  const stars = [[18, 50], [30, 70], [48, 46], [52, 72]].map((p, i) => `<circle class="sr" style="animation-delay:${i * .5}s" cx="${p[0]}" cy="${p[1]}" r="1.600"/>`).join('');
  const hearts = [[104, 12], [126, 30], [84, 24], [142, 54], [70, 44], [118, 6]].map((p, i) => `<g transform="translate(${p[0]} ${p[1]})"><path style="animation-delay:${i * .25}s" d="${HT}"/></g>`).join('');
  const sparks = [[22, 108], [298, 84], [62, 14], [282, 36], [300, 130]].map((p, i) => `<g transform="translate(${p[0]} ${p[1]})"><path style="animation-delay:${i * .3}s" d="${STR}"/></g>`).join('');
  return `<svg viewBox="0 0 320 252" id="sk" data-s="idle" data-v="" role="img" aria-label="Two little skeletons: a girl reading at her desk and a boy who visits her" xmlns="http://www.w3.org/2000/svg">
<g transform="translate(0 20)">
<path class="wire" d="M0 -4 Q40 18 80 0 T160 2 T240 0 T320 -6"/>${lights}
<g><rect class="win" x="8" y="34" width="54" height="48" rx="8"/><path class="mn" d="M44 44 A11 11 0 1 0 52 62 A9 9 0 1 1 44 44Z"/>${stars}<path class="wf" d="M35 36 V80 M10 58 H60"/></g>
<ellipse class="glow" cx="248" cy="132" rx="64" ry="42"/>
<ellipse class="shadow" cx="160" cy="214" rx="140" ry="7"/>
<g transform="translate(100 0)"><rect class="chr" x="-32" y="100" width="64" height="52" rx="16"/>${torso(24, 26)}
 <g transform="translate(0 100)"><g class="j" data-j="gh"><g class="wk0">${face(false).replace('translate(0 -100)', 'translate(0 -100)')}</g></g></g>
 ${arm(-26, 'g', 'L', 26, 22)}${arm(26, 'g', 'R', 26, 22)}
</g>
<g transform="translate(172 0)"><g class="j boy" data-j="bx"><g class="wk"><g transform="translate(0 150)"><g class="j" data-j="bl"><g transform="translate(0 -150)">
 ${torso(28, 24)}${[0,1,2,3].map(i=>`<rect class="vt" x="-3" y="${146+i*9}" width="6" height="7" rx="3"/>`).join('')}<path class="sh" d="M-24 180 Q-24 198 -9 203 L0 193 L9 203 Q24 198 24 180 Q12 173 0 182 Q-12 173 -24 180Z"/><path class="tie" d="M0 112 L-12 105 L-12 119Z M0 112 L12 105 L12 119Z"/><circle class="tie" cx="0" cy="112" r="3"/>
 <g transform="translate(0 100)"><g class="j" data-j="bh">${face(true)}</g></g>
 ${arm(-24, 'b', 'L', 30, 26, FLOWER(26))}${arm(24, 'b', 'R', 30, 26)}
</g></g></g></g></g></g>
<g class="books"><rect class="bk1" x="14" y="139" width="40" height="11" rx="2"/><rect class="bk2" x="18" y="128" width="34" height="11" rx="2"/><rect class="bk3" x="16" y="118" width="36" height="10" rx="2"/></g>
<g transform="translate(180 150)"><g class="j" data-j="mug"><g class="stm"><path class="st" d="M-4 -18 q-4 -6 0 -12 q4 -6 0 -12"/><path class="st" d="M4 -18 q-4 -6 0 -12 q4 -6 0 -12" style="animation-delay:.9s"/></g><rect class="mg" x="-10" y="-16" width="20" height="16" rx="4"/><ellipse class="tea" cx="0" cy="-15" rx="8.500" ry="2.500"/><path class="mh" d="M10 -12 q9 0 9 6 q0 6 -9 6"/><path class="mt" d="M-3 -9 C-8 -13 -3 -15 0 -11 C3 -15 8 -13 3 -9 L0 -6Z"/><g class="mhand" transform="translate(14 -6) rotate(-90)">${B('M0 0 L0 6', 5)}${handArt(2)}</g></g></g>
<g class="lamp"><path class="la" d="M262 148 L252 104 L232 92"/><ellipse class="lb" cx="262" cy="148" rx="17" ry="5"/><path class="ls" d="M214 84 L244 76 L254 100 L224 108Z"/><ellipse class="lbulb" cx="238" cy="104" rx="9" ry="3.500"/></g>
<rect class="dk" x="2" y="150" width="302" height="10" rx="4"/><rect class="df" x="8" y="160" width="290" height="46" rx="8"/><ellipse class="hd" cx="64" cy="184" rx="8" ry="3"/><ellipse class="hd" cx="236" cy="184" rx="8" ry="3"/>
<g class="book"><path class="cv" d="M64 153 L100 160 L136 153 L136 157 L100 164 L64 157Z"/><path class="pgs" d="M66 152 L100 158 L100 144 L68 138Z"/><path class="pgs" d="M100 158 L134 152 L132 138 L100 144Z"/><path class="ln" d="M72 144 L94 148 M72 148 L94 152 M106 148 L128 144 M106 152 L128 148"/><path class="pgs flip" d="M100 158 L134 152 L132 138 L100 144Z"/></g>
<g class="fx"><g class="ht">${hearts}</g><text class="mw" x="116" y="4">mwah</text><g class="spk">${sparks}</g></g>
<g class="zzz"><text x="124" y="52">z</text><text x="136" y="38">z</text><text x="148" y="24">z</text></g>
</g></svg>`;
}

const BASE = { gaL: [0, 0, 30], gfL: [0, 0, -99], gaR: [0, 0, -30], gfR: [0, 0, 99], gh: [0, 3, 0], mug: [0, 0, 0], bx: [200, 0, 0], bl: [0, 0, 0], bh: [0, 0, 0], baL: [0, 0, 5], bfL: [0, 0, -3], baR: [0, 0, -5], bfR: [0, 0, 3] };
const GS = {
  study: { gh: [0, 8, 4] },
  sleep: { gh: [0, 22, 14], gaL: [0, 0, 44], gfL: [0, 0, -120], gaR: [0, 0, -44], gfR: [0, 0, 120] },
  sip: { mug: [-68, -50, -8], gaR: [0, 0, -100], gfR: [0, 0, 112] },
  wave: { gaR: [0, 0, -150], gfR: [0, 0, 20] },
  think: { gaR: [0, 0, -104], gfR: [0, 0, 136], gh: [0, 3, -6] },
  wow: { gaL: [0, 0, 56], gfL: [0, 0, -60], gaR: [0, 0, -56], gfR: [0, 0, 60], gh: [0, 0, 0] }
};
const VP = {
  in: { bx: [0, 0, 0] },
  out: {},
  pat: { bx: [-8, 0, 0], bl: [0, 0, -5], baL: [0, 0, 158], bfL: [0, 0, 0], gh: [0, 8, 4] },
  kiss: { bx: [-26, -20, 0], bl: [0, 0, -12], bh: [-4, -2, 26], baL: [0, 0, 96], bfL: [0, 0, -24], gh: [0, 7, -4] },
  hug: { bx: [-24, 0, 0], bl: [0, 0, -8], bh: [-2, 0, 18], baL: [0, 0, 98], bfL: [0, 0, -40], gh: [-2, 5, 10], gaR: [0, 0, -78], gfR: [0, 0, 70] },
  five: { bx: [-10, 0, 0], baL: [0, 0, 178], bfL: [0, 0, 0], gaR: [0, 0, -168], gfR: [0, 0, 0] },
  flower: { bx: [-26, 0, 0], bl: [0, 0, -6], baL: [0, 0, 92], bfL: [0, 0, 88], gh: [0, 6, 6] },
  clap: { bx: [-12, 0, 0], baL: [0, 0, 20], bfL: [0, 0, -175], baR: [0, 0, -20], bfR: [0, 0, 175], gaL: [0, 0, 20], gfL: [0, 0, -175], gaR: [0, 0, -20], gfR: [0, 0, 175] },
  dance: { bx: [-12, 0, 0], baL: [0, 0, 140], baR: [0, 0, -140], gaL: [0, 0, 140], gaR: [0, 0, -140] }
};

return { svg: scene, BASE, GS, VP };
})();
function skeletonSVG() { return SK.svg(); }
const MK = '<svg class="mk" viewBox="0 0 40 40" aria-hidden="true"><path class="sh" d="M12 24 Q12 32 20 32 Q28 32 28 24Z"/><ellipse class="sh" cx="20" cy="17" rx="13" ry="12"/><ellipse class="e" cx="15" cy="17" rx="3.400" ry="4"/><ellipse class="e" cx="25" cy="17" rx="3.400" ry="4"/><circle class="w" cx="14" cy="15.500" r="1.200"/><circle class="w" cx="24" cy="15.500" r="1.200"/><path class="m" d="M16 25.500 Q20 28.500 24 25.500"/><path class="bw" d="M31 6 L38 2 L38 11Z M31 6 L25 2 L25 10Z"/></svg>';

let temp = null, tmo, vk = '', vt, want = '';
const ACT = ['pat', 'kiss', 'hug', 'five', 'flower', 'clap'];
const WHO = { cheer: ['five', 'clap', 'pat'], love: ['kiss', 'hug', 'flower', 'pat'] };
const GF = { sleep: 'sleep', wow: 'wow', sip: 'happy' };
const pick = a => a[Math.floor(Math.random() * a.length)];
function poke() { if (Math.random() < .35) react(pick(['wave', 'think', 'wow']), 2400); else visit(pick(ACT)); }
function setV(v) { vk = v; paintMascot(); }
function leave() { setV('out'); vt = setTimeout(() => setV(''), 1250); }
/* he walks in, does the action, lowers his arms, then walks out again */
function visit(kind) {
  want = kind; clearTimeout(vt);
  const finish = () => { setV('in'); vt = setTimeout(leave, 700); };
  const act = () => { setV(want); vt = setTimeout(finish, want === 'dance' ? 5200 : 2800); };
  const was = vk;
  if (was && was !== 'in' && was !== 'out') act();
  else { setV('in'); vt = setTimeout(act, was === 'in' ? 350 : 1250); }
}
const happy = () => visit(pick(ACT));
function baseState() {
  if (T.run && T.mode === 'focus') return 'study';
  const n = SS()[cur()];
  if (n && /sleep/i.test(n.l)) return 'sleep';
  return 'idle';
}
function paintMascot() {
  const sk = $('#sk'); if (!sk) return;
  const gs = temp || baseState(), act = !!vk && vk !== 'in' && vk !== 'out';
  sk.dataset.s = gs; sk.dataset.v = vk; sk.classList.toggle('act', act);
  sk.dataset.f = act ? 'happy' : (GF[gs] || '');
  $('#mascot').classList.toggle('big', !!vk);
  const o = Object.assign({}, SK.BASE, SK.GS[gs] || {}, SK.VP[vk] || {});
  Object.keys(SK.BASE).forEach(k => { const e = sk.querySelector(`[data-j="${k}"]`); if (e) { const v = o[k]; e.style.transform = `translate(${v[0]}px,${v[1]}px) rotate(${v[2]}deg)`; } });
}
function react(s, ms) {
  if (s === 'dance' || s === 'cheer' || s === 'love') { visit(s === 'dance' ? 'dance' : pick(WHO[s])); return; }
  temp = s; clearTimeout(tmo); tmo = setTimeout(() => { temp = null; paintMascot(); }, ms); paintMascot();
}

function buddyText() {
  const L = SS(), c = cur(), now = L[c], nx = L[c + 1], d = doneCount();
  if (T.run && T.mode === 'focus') return ['Focus time. You have got this!', 'One thing at a time.'];
  if (T.run && T.mode === 'rest') return ['Break time.', 'Stretch and sip some water.'];
  if (L.length && d === L.length) return ['You did everything today. So proud of you!', 'Time to rest.'];
  if (now && /sleep/i.test(now.l)) return ['Shh, it is sleepy time.', nx ? 'Next: ' + nx.l + ' at ' + f(nx.m) : ''];
  if (now) return ['Now: ' + now.l, nx ? 'Next: ' + nx.l + ' at ' + f(nx.m) : 'Last one for today'];
  return ['Hi!', ''];
}
function updateProgress() {
  const L = SS(), d = doneCount(), p = L.length ? d / L.length : 0, sk = $('#sk');
  if (sk) sk.classList.toggle('full', p >= 1 && L.length > 0);
  const [t, s] = buddyText();
  $('#bt').textContent = t; $('#bs').textContent = s; $('#bs').hidden = !s;
  $('#bbar').style.width = Math.round(p * 100) + '%';
  $('#bcnt').textContent = d + ' of ' + L.length + ' done today';
  paintMascot();
}

/* =====================================================================
   Images (custom pictures are kept in IndexedDB so state stays small)
   ===================================================================== */
const IDB = {
  db: null, mem: new Map(),
  open() { return new Promise(res => { try { const r = indexedDB.open('enon-planner', 1); r.onupgradeneeded = () => r.result.createObjectStore('img'); r.onsuccess = () => { IDB.db = r.result; res(); }; r.onerror = () => res(); } catch (e) { res(); } }); },
  tx(mode, fn) { return new Promise(res => { if (!IDB.db) return res(null); try { const t = IDB.db.transaction('img', mode), r = fn(t.objectStore('img')); t.oncomplete = () => res(r ? r.result : true); t.onerror = () => res(null); t.onabort = () => res(null); } catch (e) { res(null); } }); },
  put(k, b) { IDB.mem.set(k, b); return IDB.tx('readwrite', s => s.put(b, k)); },
  get(k) { return IDB.mem.has(k) ? Promise.resolve(IDB.mem.get(k)) : IDB.tx('readonly', s => s.get(k)); },
  del(k) { IDB.mem.delete(k); return IDB.tx('readwrite', s => s.delete(k)); }
};
const URLS = {};
const imgSrc = k => URLS[k] || ('assets/' + k + '.png');
async function loadImages() {
  await IDB.open();
  const keys = [...Object.keys(S.img).filter(k => S.img[k]), ...S.gal];
  for (const k of keys) { try { const b = await IDB.get(k); if (b) URLS[k] = URL.createObjectURL(b); } catch (e) {} }
  apply(); renderBoard();
}
const readImg = (file, max, type) => new Promise((ok, no) => {
  const u = URL.createObjectURL(file), im = new Image();
  im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); c.toBlob(b => b ? ok(b) : no(), type, .85); };
  im.onerror = () => { URL.revokeObjectURL(u); no(); };
  im.src = u;
});
let target = '';
async function upload(files) {
  const msg = target === 'gal' ? $('#gmsg') : $('#smsg'); msg.textContent = '';
  try {
    if (target === 'gal') {
      for (const file of files.slice(0, 6)) {
        if (S.gal.length >= 12) { msg.textContent = 'The board is full, remove a photo first.'; break; }
        const blob = await readImg(file, 720, 'image/jpeg'), id = 'g' + Date.now() + Math.floor(Math.random() * 1000);
        const ok = await IDB.put(id, blob);
        URLS[id] = URL.createObjectURL(blob); S.gal.push(id);
        if (!ok) msg.textContent = 'Saved for now, but this phone would not store it long term.';
      }
      renderBoard();
    } else {
      const blob = await readImg(files[0], target === 'av' ? 480 : 300, target === 'av' ? 'image/jpeg' : 'image/png');
      const ok = await IDB.put(target, blob);
      if (URLS[target] && S.img[target]) URL.revokeObjectURL(URLS[target]);
      URLS[target] = URL.createObjectURL(blob); S.img[target] = 1; apply();
      if (!ok) msg.textContent = 'Saved for now, but this phone would not store it long term.';
    }
    persist();
  } catch (e) { msg.textContent = 'That picture could not be loaded.'; }
}

/* =====================================================================
   Timer (uses an end time, so it stays correct when the phone sleeps)
   ===================================================================== */
const T = {mode:'focus', left:S.tcfg.f * 60, end:0, run:false};
if (S.timer && typeof S.timer === 'object') {
  T.mode = S.timer.mode === 'rest' ? 'rest' : 'focus'; T.left = S.timer.left || T.left;
  if (S.timer.run && S.timer.end > Date.now()) { T.run = true; T.end = S.timer.end; }
  else if (S.timer.run) { T.left = (T.mode === 'focus' ? S.tcfg.f : S.tcfg.b) * 60; }
}
const tLen = m => (m === 'focus' ? S.tcfg.f : S.tcfg.b) * 60;
const tLeft = () => T.run ? Math.max(0, Math.round((T.end - Date.now()) / 1000)) : T.left;
let AC;
function beep() {
  try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const o = AC.createOscillator(), g = AC.createGain(); o.connect(g); g.connect(AC.destination); o.type = 'sine'; o.frequency.value = 880; g.gain.setValueAtTime(.0001, AC.currentTime); g.gain.exponentialRampToValueAtTime(.25, AC.currentTime + .02); g.gain.exponentialRampToValueAtTime(.0001, AC.currentTime + .6); o.start(); o.stop(AC.currentTime + .65); } catch (e) {}
  try { navigator.vibrate && navigator.vibrate([120, 80, 120]); } catch (e) {}
}
function tTick() {
  let n = 0;
  while (T.run && Date.now() >= T.end && n++ < 20) {
    if (T.mode === 'focus') S.focusToday += S.tcfg.f;
    T.mode = T.mode === 'focus' ? 'rest' : 'focus'; T.end += tLen(T.mode) * 1000;
    beep(); persist();
    if (T.mode === 'rest') react('cheer', 1500);
    updateProgress();
  }
  drawTimer();
}
function drawTimer() {
  const l = tLeft(), tot = tLen(T.mode);
  $('#tt').textContent = pad(Math.floor(l / 60)) + ':' + pad(l % 60);
  $('#tm').textContent = T.mode === 'focus' ? 'Focus' : 'Break';
  $('#tp').style.strokeDashoffset = 213.6 * (1 - Math.min(1, l / tot));
  $('#go').textContent = T.run ? 'Pause' : 'Start';
  $('#tfoc').textContent = S.focusToday ? 'Focused today: ' + S.focusToday + ' min' : 'Focus sessions you finish add up here.';
}
setInterval(() => { if (T.run) tTick(); }, 500);

/* =====================================================================
   Rendering
   ===================================================================== */
const row = (s, now) => `<button class="it${S.done[s.id] ? ' d' : ''}${s.a ? ' add' : ''}${now ? ' now' : ''}" data-a="tick" data-id="${s.id}" aria-pressed="${!!S.done[s.id]}">${now ? MK : ''}<span class="tm">${f(s.m)}</span><span class="lb">${esc(s.l)}${s.only ? '<em class="tag">today</em>' : ''}</span>${CK}</button>`;


const QK = ['Break', 'Meal', 'Question solve', 'Revision', 'Notes', 'Cardio, 30 min', 'Free time', 'Sleep'];
function addBox(p, t, act) {
  return `<div class="addbox"><div class="lab">Add something</div><div class="ed er"><input type="time" id="${p}t" value="${hh(t)}" aria-label="Time"><button class="btn" data-a="${act}">Add</button><input type="text" id="${p}l" placeholder="What are you doing?" aria-label="New task" autocomplete="off" enterkeyhint="done"></div>`
    + `<div class="chips qk">${QK.map(q => `<button class="chip sm" data-a="qk" data-fill="${p}l" data-v="${esc(q)}">${esc(q)}</button>`).join('')}</div>`
    + `<select class="pick" data-fill="${p}l" aria-label="Study a chapter"><option value="">Study a chapter...</option>${S.subj.map(x => `<option value="${x.id}">${esc(x.n)}: next chapter</option>`).join('')}</select></div>`;
}

function renderSched() {
  const L = SS(), c = cur(), v = S.view, ed = !!EDIT.sched; let h = '';
  $('#seg').hidden = ed; $('#shint').hidden = ed;
  if (ed) {
    h = '<p class="hint" style="margin:0 0 10px">Change a time or a name right here. Tap &times; to remove a row.</p>'
      + L.map(s => `<div class="ed er"><input type="time" value="${hh(s.m)}" data-et="${s.id}" aria-label="Time"><button class="x" data-a="sdel" data-id="${s.id}" aria-label="Delete task">&times;</button><input type="text" value="${esc(s.l)}" data-el="${s.id}" aria-label="Task" autocomplete="off"></div>`).join('')
      + addBox('s', L.length ? Math.min(1380, L[L.length - 1].m + 60) : 540, 'sadd')
      + '<div class="lab" style="margin-top:16px">Reuse and reset</div><div class="chips"><button class="btn ghost sm" data-a="savep">Save as my plan</button><button class="btn ghost sm" data-a="rtick">Untick everything</button><button class="btn ghost sm" data-a="rstart">Back to starter plan</button></div>';
  } else if (v === 'timeline') {
    h = '<div class="tl">' + L.map((s, i) => row(s, i === c)).join('') + '</div>';
  } else if (v === 'blocks') {
    h = [['Night','12 AM to 6 AM',0,360],['Morning','6 AM to 12 PM',360,720],['Afternoon','12 PM to 6 PM',720,1080],['Evening','6 PM to 12 AM',1080,1441]].map(g => '<div class="pgrp"><div class="gh">' + g[0] + '<span>' + g[1] + '</span></div>' + L.map(s => s.m >= g[2] && s.m < g[3] ? row(s, 0) : '').join('') + '</div>').join('');
  } else if (L.length) {
    h = '<div class="nowbox"><small>Now</small><div class="big">' + esc(L[c].l) + '</div><div>' + f(L[c].m) + '</div></div>'
      + (L[c + 1] ? '<div class="lab">Up next</div>' + row(L[c + 1], 0) : '')
      + (L[c + 2] ? '<div class="lab" style="margin-top:10px">Later today</div>' + L.slice(c + 2, c + 5).map(s => row(s, 0)).join('') : '');
  }
  $('#list').innerHTML = h;
  $$('#seg button').forEach(b => b.setAttribute('aria-pressed', b.dataset.id === v));
  updateProgress();
}

function renderTodos() {
  const ed = !!EDIT.todo;
  $('#todos').innerHTML = S.todos.map((t, i) => `<div class="td"><button class="it${t.d ? ' d' : ''}" data-a="td" data-id="${i}" aria-pressed="${!!t.d}">${CK}<span class="lb">${esc(t.t)}</span></button>${ed ? `<button class="x" data-a="tdx" data-id="${i}" aria-label="Remove">&times;</button>` : ''}</div>`).join('');
  renderCarry();
}
function renderCarry() {
  $('#carry').innerHTML = S.carry ? `<div class="carry"><b>From yesterday</b><p>${esc(S.carry)}</p><div class="chips"><button class="btn ghost sm" data-a="carryadd">Add to my list</button><button class="btn ghost sm" data-a="carryx">Dismiss</button></div></div>` : '';
}

function renderHabits() {
  const ed = !!EDIT.habits;
  $('#wlab').textContent = 'Water, ' + S.goal + ' glasses';
  $('#cups').innerHTML = Array.from({length:S.goal}, (_, i) => `<button class="cup${i < S.water ? ' on' : ''}" data-a="w" data-id="${i}" aria-label="Glass ${i + 1}"></button>`).join('');
  $('#goaledit').innerHTML = ed ? `<div class="row"><div class="lab">Water goal, glasses</div><div class="step"><button data-a="goal" data-d="-1" aria-label="Fewer glasses">-</button><b>${S.goal}</b><button data-a="goal" data-d="1" aria-label="More glasses">+</button></div></div>` : '';
  $('#prs').innerHTML = PRAYERS.map((n, i) => `<button class="chip${S.pr[i] ? ' on' : ''}" data-a="pr" data-id="${i}" aria-pressed="${!!S.pr[i]}">${CK}${n}</button>`).join('');
  $('#habs').innerHTML = S.habs.map((h, i) => `<button class="chip${h.d ? ' on' : ''}" data-a="hb" data-id="${i}" aria-pressed="${!!h.d}">${CK}${esc(h.n)}</button>` + (ed ? `<button class="x" data-a="hbx" data-id="${i}" aria-label="Remove habit">&times;</button>` : '')).join('') || (ed ? '' : '<span class="hint" style="margin:0">Tap Edit to add a habit.</span>');
  $('#habadd').innerHTML = ed ? '<div class="addrow"><input id="newh" placeholder="New habit" aria-label="New habit" autocomplete="off"><button class="btn" data-a="hbadd">Add</button></div>' : '';
  $('#sv').textContent = S.screen;
}

function renderStudy() {
  const A = S.subj, ed = !!EDIT.study;
  let k = A.findIndex(x => x.id === S.sel); if (k < 0 && A.length) { k = 0; S.sel = A[0].id; }
  const addSub = `<div class="addrow"><input id="nsub" placeholder="New subject" aria-label="New subject" autocomplete="off"><button class="btn" data-a="subadd">Add</button></div>`;
  if (!A.length) { $('#subs').innerHTML = ''; $('#subhead').innerHTML = ''; $('#chs').innerHTML = ''; $('#subedit').innerHTML = ed ? '<div class="sedit">' + addSub + '<div class="addrow"><button class="btn ghost" data-a="srest">Restore presets</button></div></div>' : '<p class="hint">No subjects yet. Tap Edit to add one.</p>'; return; }
  const sj = A[k], col = SC[k % SC.length], pc = x => x.ch.length ? Math.round(x.ch.filter(c => c.s === 2).length * 100 / x.ch.length) : 0;
  $('#subs').innerHTML = A.map((x, i) => `<button class="sb${i === k ? ' on' : ''}" data-a="sub" data-id="${x.id}" style="--c:${SC[i % SC.length]}" aria-pressed="${i === k}"><i></i><span class="sbn">${esc(x.n)}</span> <small>${pc(x)}%</small></button>`).join('');
  const rv = sj.ch.filter(c => c.s === 2).length, ln = sj.ch.filter(c => c.s === 1).length;
  $('#subhead').innerHTML = `<div class="pbar sp" style="--c:${col}"><i style="width:${pc(sj)}%"></i></div><p class="hint" style="margin:0 0 10px">${rv} revised, ${ln} in progress, ${sj.ch.length - rv - ln} to start. Tap the circle to change progress, tap + to add it to today.</p>`;
  $('#chs').innerHTML = sj.ch.map(c => ed
    ? `<div class="ch"><input data-cn="${c.id}" value="${esc(c.n)}" aria-label="Chapter name" autocomplete="off"><button class="x" data-a="cx" data-id="${c.id}" aria-label="Delete chapter">&times;</button></div>`
    : `<div class="ch s${c.s}" style="--c:${col}"><button class="sd s${c.s}" data-a="cs" data-id="${c.id}" aria-label="${LBL[c.s]}, tap to change"><i>${c.s === 2 ? CHK : ''}</i></button><span>${esc(c.n)}</span><button class="pl" data-a="ca" data-id="${c.id}" aria-label="Add ${esc(c.n)} to today">+</button></div>`).join('');
  $('#subedit').innerHTML = ed ? `<div class="sedit"><div class="addrow"><textarea id="newc" rows="2" placeholder="New chapters, one per line" aria-label="New chapters, one per line"></textarea><button class="btn" data-a="cadd">Add</button></div><div class="addrow"><input id="sname" value="${esc(sj.n)}" aria-label="Subject name" autocomplete="off"><button class="btn ghost" data-a="subdel">Delete subject</button></div>${addSub}<div class="addrow"><button class="btn ghost" data-a="srest">Restore presets</button></div></div>` : '';
}

function renderNotes() {
  const ed = !!EDIT.notes;
  $('#nbody').innerHTML = ed ? `<textarea id="ne" aria-label="Notes, one per line">${esc(S.notes.join('\n'))}</textarea><div class="addrow"><input id="nse" value="${esc(S.script)}" aria-label="Handwritten line" autocomplete="off"></div><p class="hint">One reminder per line.</p>` : '<ul>' + S.notes.map(n => '<li>' + esc(n) + '</li>').join('') + '</ul><div class="script">' + esc(S.script) + '</div>';
}
function renderBoard() {
  const ed = !!EDIT.board;
  $('#gal').innerHTML = S.gal.map((g, i) => URLS[g] ? `<figure><img src="${URLS[g]}" alt="Board photo ${i + 1}">${ed ? `<button class="x" data-a="gx" data-id="${i}" aria-label="Remove photo">&times;</button>` : ''}</figure>` : '').join('');
}
function renderMood() {
  $('#mood').innerHTML = MOODS.map((n, i) => `<button class="chip${S.mood === i ? ' on' : ''}" data-a="mood" data-id="${i}" aria-pressed="${S.mood === i}">${n}</button>`).join('');
}
function renderTimerCfg() {
  $('#tcfg').innerHTML = EDIT.timer ? `<div class="row"><div class="lab">Focus length, minutes</div><div class="step"><button data-a="tcfg" data-k="f" data-d="-5" aria-label="Shorter focus">-</button><b>${S.tcfg.f}</b><button data-a="tcfg" data-k="f" data-d="5" aria-label="Longer focus">+</button></div></div><div class="row"><div class="lab">Break length, minutes</div><div class="step"><button data-a="tcfg" data-k="b" data-d="-1" aria-label="Shorter break">-</button><b>${S.tcfg.b}</b><button data-a="tcfg" data-k="b" data-d="1" aria-label="Longer break">+</button></div></div>` : '';
}
const SECTIONS = {sched:renderSched, todo:renderTodos, study:renderStudy, habits:renderHabits, notes:renderNotes, board:renderBoard, timer:renderTimerCfg};
function renderSection(id) { (SECTIONS[id] || (() => {}))(); $$(`.pen[data-id="${id}"]`).forEach(b => b.setAttribute('aria-pressed', !!EDIT[id])); }

function apply() {
  $('#nm').textContent = S.name; $('#hd').textContent = S.head; document.title = (S.name + ' ' + S.head).trim();
  $('#avimg').src = imgSrc('av'); $('#iav').src = imgSrc('av'); $('#stimg').src = imgSrc('st');
  const P = PALS[S.pal] || PALS[0], r = document.documentElement.style;
  r.setProperty('--accbase', S.acc || P[1]); r.setProperty('--sec', P[2]); r.setProperty('--ter', P[3]);
  $('#ig1').textContent = S.g1; $('#ig2').textContent = S.g2;
  $('#date').textContent = new Date().toLocaleDateString(undefined, {weekday:'long', day:'numeric', month:'long'});
}
function showTab(id) {
  if (!$('#tab-' + id)) id = 'today';
  S.tab = id;
  $$('.tab').forEach(t => t.classList.toggle('on', t.id === 'tab-' + id));
  $$('.tabbar button').forEach(b => b.setAttribute('aria-pressed', b.dataset.id === id));
  window.scrollTo(0, 0);
}
function renderAll() {
  apply(); renderSched(); renderTodos(); renderHabits(); renderStudy(); renderNotes(); renderBoard(); renderMood(); renderTimerCfg(); drawTimer();
  $$('[data-pi]').forEach(i => i.value = S.pri[i.dataset.pi] || '');
  $('#win').value = S.win; $('#tom').value = S.tom;
  Object.keys(SECTIONS).forEach(k => $$(`.pen[data-id="${k}"]`).forEach(b => b.setAttribute('aria-pressed', !!EDIT[k])));
}
function renderSheet() {
  $('#sn').value = S.name; $('#sh').value = S.head; $('#s1').value = S.g1; $('#s2').value = S.g2;
  $('#sw').innerHTML = PALS.map((p, i) => `<button class="sw${!S.acc && S.pal === i ? ' on' : ''}" data-a="pal" data-id="${i}" aria-label="${p[0]} colors" style="background:${p[1]}"></button>`).join('') + `<input type="color" id="cc" value="${S.acc || PALS[S.pal][1]}" aria-label="Pick your own color">`;
  $('#alw').classList.toggle('on', !!S.always); $('#alw').setAttribute('aria-pressed', !!S.always);
  $('#smsg').textContent = '';
}


/* ---------- plans sheet ---------- */
const DN = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const WK = [1, 2, 3, 4, 5, 6, 0];
let PV = {v:'home'};
const planCard = p => `<button class="pc" data-a="pview" data-id="${esc(p.id)}"><b>${esc(p.n)}</b><small>${esc(p.d)}</small></button>`;
const timeRows = items => '<div class="pv">' + items.map(i => `<div class="pr"><span>${f(i.m)}</span><i>${esc(i.l)}</i></div>`).join('') + '</div>';
const dayChips = (on, act) => '<div class="chips">' + WK.map(d => `<button class="chip${on(d) ? ' on' : ''}" data-a="${act}" data-d="${d}" aria-pressed="${!!on(d)}">${DN[d].slice(0, 3)}</button>`).join('') + '</div>';
function planHead(t, back) { return `<div class="chd">${back ? '<button class="btn ghost" data-a="pback">Back</button>' : ''}<h2>${t}</h2><button class="btn" data-a="pclose">Done</button></div>`; }

function renderPlans() {
  const el = $('#pbody'); let h = '';
  if (PV.v === 'home') {
    const all = allPlans(), mine = all.filter(x => x.mine), std = all.filter(x => !x.mine);
    h = planHead('Plans')
      + '<p class="hint" style="margin:0 0 12px">Pick a plan and your whole day sets itself up. You can still edit anything afterwards.</p>'
      + '<button class="btn big" data-a="pnew">+ Create my own plan</button>'
      + (mine.length ? '<div class="lab">My plans</div><div class="pcs">' + mine.map(planCard).join('') + '</div>' : '')
      + '<div class="lab">Ready-made plans</div><div class="pcs">' + std.map(planCard).join('') + '</div>'
      + '<div class="lab">My week</div><p class="hint" style="margin:0 0 8px">Choose a plan for each day. It loads by itself every morning.</p>'
      + WK.map(d => `<div class="wkr"><span>${DN[d]}</span><select class="pick" data-wk="${d}" aria-label="Plan for ${DN[d]}"><option value="">Keep my schedule</option>${mine.length ? '<optgroup label="My plans">' + mine.map(x => `<option value="${esc(x.id)}"${S.week[d] === x.id ? ' selected' : ''}>${esc(x.n)}</option>`).join('') + '</optgroup>' : ''}<optgroup label="Ready-made">${std.map(x => `<option value="${esc(x.id)}"${S.week[d] === x.id ? ' selected' : ''}>${esc(x.n)}</option>`).join('')}</optgroup></select></div>`).join('')
      + '<div class="lab">Reset</div><div class="chips"><button class="btn ghost sm" data-a="rtick">Untick everything</button><button class="btn ghost sm" data-a="rstart">Back to starter plan</button></div>';
  } else if (PV.v === 'view') {
    const p = planById(PV.id); if (!p) { PV = {v:'home'}; return renderPlans(); }
    h = planHead(esc(p.n), 1) + `<p class="hint" style="margin:0 0 10px">${esc(p.d)}</p>` + timeRows(p.items())
      + '<button class="btn big stick" data-a="puse">Use for today</button>'
      + '<div class="lab">Repeat every</div>' + dayChips(d => S.week[d] === p.id, 'pwd')
      + '<div class="chips" style="margin-top:14px"><button class="btn ghost sm" data-a="pcopy">' + (p.mine ? 'Edit this plan' : 'Make my own copy') + '</button>' + (p.mine ? '<button class="btn ghost sm" data-a="pdel">Delete</button>' : '') + '</div>';
  } else {
    const d = PV.draft;
    h = planHead(d.id ? 'Edit plan' : 'New plan', 1)
      + `<div class="fld"><label for="pn">Plan name</label><input type="text" id="pn" value="${esc(d.n)}" placeholder="e.g. Anatomy Monday" autocomplete="off"></div>`
      + (d.items.length ? '' : '<p class="hint">Nothing here yet. Add your first item below, or start from a ready-made plan.</p>')
      + d.items.map((x, i) => `<div class="ed er"><input type="time" value="${hh(x.m)}" data-dt="${i}" aria-label="Time"><button class="x" data-a="pdx" data-id="${i}" aria-label="Remove">&times;</button><input type="text" value="${esc(x.l)}" data-dl="${i}" aria-label="Task" autocomplete="off"></div>`).join('')
      + addBox('p', d.items.length ? Math.min(1380, d.items[d.items.length - 1].m + 60) : 540, 'pdadd')
      + '<div class="lab" style="margin-top:16px">Start from</div><div class="chips"><button class="btn ghost sm" data-a="pfrom" data-id="today">Today\'s schedule</button>' + builtIns().slice(0, 1).concat(builtIns().filter(x => x.id === 'b:mix' || x.id === 'b:light')).map(x => `<button class="btn ghost sm" data-a="pfrom" data-id="${esc(x.id)}">${esc(x.n)}</button>`).join('') + '</div>'
      + '<div class="lab" style="margin-top:16px">Repeat every</div>' + dayChips(k => d.days.includes(k), 'pdd')
      + '<div class="chips" style="margin-top:16px"><button class="btn" data-a="psave">Save plan</button><button class="btn ghost" data-a="psaveuse">Save and use today</button></div>';
  }
  const top = el.scrollTop; el.innerHTML = h; el.scrollTop = PV.keep ? top : 0; PV.keep = 0;
}
function openPlans(v, extra) { PV = Object.assign({v:v || 'home'}, extra || {}); renderPlans(); $('#plans').hidden = false; }
function useToday(items, msg) {
  undoable(msg || 'Plan applied');
  S.sched = fresh(items); S.done = {}; EDIT.sched = false;
  renderSection('sched'); updateProgress(); react('wave', 2200);
}

/* ---------- toast + undo ---------- */
let UNDO = null, tt;
function toast(msg, undo) {
  const el = $('#toast'); el.innerHTML = '<span>' + esc(msg) + '</span>' + (undo ? '<button data-a="undo">Undo</button>' : '');
  el.classList.add('on'); UNDO = undo || null; clearTimeout(tt);
  tt = setTimeout(() => { el.classList.remove('on'); UNDO = null; }, undo ? 6500 : 2800);
}
function undoable(msg) {
  const snap = JSON.stringify(S);
  toast(msg, () => { S = Object.assign(def(), JSON.parse(snap)); renderAll(); persist(); });
}

/* ---------- intro ---------- */
function intro() {
  const el = $('#intro'); el.hidden = false; el.classList.remove('out');
  if (!el.dataset.b) { el.dataset.b = 1; for (let i = 0; i < 16; i++) { const b = document.createElement('span'), s = 12 + Math.random() * 34; b.className = 'bub'; b.style.cssText = `width:${s}px;height:${s}px;left:${Math.random() * 100}%;background:var(${i % 2 ? '--acc' : '--sec'});animation-duration:${9 + Math.random() * 9}s;animation-delay:${-Math.random() * 12}s`; el.prepend(b); } }
}

/* =====================================================================
   Events
   ===================================================================== */
const flip = (b, on) => { b.classList.toggle('d', on); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); };

document.addEventListener('click', e => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const a = b.dataset.a, id = b.dataset.id, d = +b.dataset.d;
  switch (a) {
    case 'tab': showTab(id); break;
    case 'edit': EDIT[id] = !EDIT[id]; renderSection(id); break;
    case 'view': S.view = id; renderSched(); break;
    case 'tick': {
      const on = !S.done[id]; if (on) S.done[id] = 1; else delete S.done[id];
      $$(`[data-a="tick"][data-id="${id}"]`).forEach(x => flip(x, on));
      const L = SS(), all = L.length && doneCount() === L.length;
      updateProgress(); if (on) { if (all) react('dance', 5000); else happy(1900); }
      break;
    }
    case 'sdel': undoable('Task deleted'); S.sched = S.sched.filter(s => s.id !== id); delete S.done[id]; renderSched(); break;
    case 'sadd': {
      const v = $('#sl').value.trim(), t = $('#st').value.split(':');
      if (!v) { $('#sl').focus(); break; }
      if (t.length === 2) { S.sched.push({id:'n' + Date.now(), m:+t[0] * 60 + +t[1], l:v, a:0}); renderSched(); const n = $('#sl'); if (n) n.focus(); }
      break;
    }
    case 'plans': openPlans('home'); return;
    case 'pclose': $('#plans').hidden = true; break;
    case 'pback': if (PV.v === 'make' && PV.draft.id) PV = {v:'view', id:PV.draft.id}; else PV = {v:'home'}; renderPlans(); return;
    case 'pview': PV = {v:'view', id}; renderPlans(); return;
    case 'puse': { const p = planById(PV.id); if (p) { useToday(p.items(), p.n + ' is set for today'); $('#plans').hidden = true; } break; }
    case 'pnew': PV = {v:'make', draft:{id:'', n:'', items:[], days:[]}}; renderPlans(); return;
    case 'pcopy': { const p = planById(PV.id); if (p) { PV = {v:'make', draft:{id:p.mine ? p.id : '', n:p.mine ? p.n : 'My ' + p.n, items:p.items().map(x => Object.assign({}, x)), days:WK.filter(d => S.week[d] === p.id)}}; renderPlans(); } return; }
    case 'pdel': undoable('Plan deleted'); S.presets = S.presets.filter(x => x.id !== PV.id); Object.keys(S.week).forEach(k => { if (S.week[k] === PV.id) delete S.week[k]; }); PV = {v:'home'}; renderPlans(); break;
    case 'pwd': { const p = planById(PV.id); if (!p) break; if (S.week[d] === p.id) delete S.week[d]; else S.week[d] = p.id; PV.keep = 1; renderPlans(); break; }
    case 'pdd': { const k = PV.draft.days, i = k.indexOf(d); if (i < 0) k.push(d); else k.splice(i, 1); PV.keep = 1; renderPlans(); return; }
    case 'pdx': PV.draft.items.splice(+id, 1); PV.keep = 1; renderPlans(); return;
    case 'pdadd': {
      const v = $('#pl').value.trim(), t = $('#pt').value.split(':');
      if (!v) { $('#pl').focus(); return; }
      if (t.length === 2) { PV.draft.items.push({m:+t[0] * 60 + +t[1], l:v, a:0}); PV.draft.items.sort((x, y) => x.m - y.m); PV.keep = 1; renderPlans(); }
      return;
    }
    case 'pfrom': { const items = id === 'today' ? SS().map(x => ({m:x.m, l:x.l, a:x.a || 0})) : (planById(id) || {items:() => []}).items(); PV.draft.items = items; PV.keep = 1; renderPlans(); return; }
    case 'psave': case 'psaveuse': {
      const d = PV.draft, items = d.items.map(x => ({m:x.m, l:x.l, a:x.a || 0})).sort((x, y) => x.m - y.m);
      if (!items.length) { toast('Add at least one item first'); return; }
      const name = d.n.trim() || 'My plan'; let pid = d.id;
      if (pid) { const o = S.presets.find(x => x.id === pid); if (o) { o.n = name; o.items = items; } else pid = ''; }
      if (!pid) { pid = 'p' + Date.now(); S.presets.push({id:pid, n:name, items}); }
      WK.forEach(k => { if (d.days.includes(k)) S.week[k] = pid; else if (S.week[k] === pid) delete S.week[k]; });
      if (a === 'psaveuse') { useToday(items, name + ' is set for today'); $('#plans').hidden = true; }
      else { toast('Plan saved'); PV = {v:'view', id:pid}; renderPlans(); }
      break;
    }
    case 'savep': openPlans('make', {draft:{id:'', n:'', items:SS().map(x => ({m:x.m, l:x.l, a:x.a || 0})), days:[]}}); return;
    case 'rtick': undoable('Ticks cleared'); S.done = {}; renderSched(); break;
    case 'rstart': useToday(planById('b:start').items(), 'Starter plan restored'); $('#plans').hidden = true; break;
    case 'qk': { const i = $('#' + b.dataset.fill); if (i) { i.value = b.dataset.v; i.focus(); } return; }
    case 'poke': poke(); return;
    case 'td': { const t = S.todos[id]; if (t) { t.d = t.d ? 0 : 1; flip(b, !!t.d); if (t.d) react('cheer', 1400); } break; }
    case 'tdx': undoable('Removed'); S.todos.splice(id, 1); renderTodos(); break;
    case 'tdadd': { const v = $('#newtd').value.trim(); if (v) { S.todos.push({t:v, d:0}); $('#newtd').value = ''; renderTodos(); } break; }
    case 'carryadd': if (S.carry) { S.todos.unshift({t:S.carry, d:0}); S.carry = ''; renderTodos(); } break;
    case 'carryx': S.carry = ''; renderCarry(); break;
    case 'w': { const n = +id + 1; const up = S.water < n; S.water = S.water === n ? n - 1 : n; if (up) react('sip', 1900); $$('.cup').forEach((c, i) => c.classList.toggle('on', i < S.water)); break; }
    case 'pr': S.pr[id] = S.pr[id] ? 0 : 1; flip(b, !!S.pr[id]); if (S.pr[id]) react('love', 2000); break;
    case 'hb': { const h = S.habs[id]; if (h) { h.d = h.d ? 0 : 1; flip(b, !!h.d); if (h.d) happy(1800); } break; }
    case 'hbx': undoable('Habit removed'); S.habs.splice(id, 1); renderHabits(); break;
    case 'hbadd': { const v = $('#newh').value.trim(); if (v) { S.habs.push({n:v, d:0}); renderHabits(); } break; }
    case 'scr': S.screen = Math.min(24, Math.max(0, S.screen + d)); $('#sv').textContent = S.screen; break;
    case 'goal': S.goal = Math.min(16, Math.max(2, S.goal + d)); S.water = Math.min(S.water, S.goal); renderHabits(); break;
    case 'mood': S.mood = S.mood === +id ? -1 : +id; renderMood(); if (S.mood >= 3) react('love', 2200); break;
    case 'sub': S.sel = id; renderStudy(); break;
    case 'cs': { const [, c] = find(id); if (c) { c.s = (c.s + 1) % 3; renderStudy(); if (c.s === 2) react('cheer', 1600); } break; }
    case 'ca': {
      const [x, c] = find(id); if (!c) break;
      const n = new Date(); let m = Math.ceil((n.getHours() * 60 + n.getMinutes() + 1) / 60) * 60;
      const used = SS().map(s => s.m); while (used.includes(m) && m < 1380) m += 60; m = Math.min(m, 1380);
      S.sched.push({id:'n' + Date.now(), m, l:x.n + ': ' + c.n, a:0, only:S.day});
      if (!c.s) c.s = 1;
      renderStudy(); renderSched(); toast('Added for today at ' + f(m));
      break;
    }
    case 'cx': undoable('Chapter deleted'); { const [x] = find(id); if (x) x.ch = x.ch.filter(c => c.id !== id); } renderStudy(); break;
    case 'cadd': { const v = $('#newc').value.split('\n').map(z => z.trim()).filter(Boolean), x = S.subj.find(y => y.id === S.sel); if (v.length && x) { v.forEach((n, i) => x.ch.push({id:'x' + Date.now() + i, n, s:0})); renderStudy(); toast(v.length > 1 ? v.length + ' chapters added' : 'Chapter added'); } break; }
    case 'subadd': { const v = $('#nsub').value.trim(); if (v) { const i = 'u' + Date.now(); S.subj.push({id:i, n:v, ch:[]}); S.sel = i; renderStudy(); } break; }
    case 'subdel': undoable('Subject deleted'); S.subj = S.subj.filter(y => y.id !== S.sel); S.sel = (S.subj[0] || {}).id || ''; renderStudy(); break;
    case 'srest': if (confirm('Restore the preset subjects? This resets all study progress.')) { undoable('Presets restored'); S.subj = mkSubj(); S.sel = 'u0'; renderStudy(); } break;
    case 'tgo':
      if (T.run) { T.left = tLeft(); T.run = false; }
      else { T.end = Date.now() + T.left * 1000; T.run = true; try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); } catch (x) {} }
      drawTimer(); updateProgress(); break;
    case 'trs': T.run = false; T.mode = 'focus'; T.left = tLen('focus'); drawTimer(); updateProgress(); break;
    case 'tcfg': { const k = b.dataset.k; S.tcfg[k] = Math.min(k === 'f' ? 90 : 30, Math.max(k === 'f' ? 5 : 1, S.tcfg[k] + d)); if (!T.run) T.left = tLen(T.mode); renderTimerCfg(); drawTimer(); break; }
    case 'gx': { const g = S.gal[id]; undoable('Photo removed'); S.gal.splice(id, 1); renderBoard(); setTimeout(() => { if (g && !S.gal.includes(g)) IDB.del(g); }, 8000); break; }
    case 'sets': renderSheet(); $('#sheet').hidden = false; break;
    case 'close': $('#sheet').hidden = true; break;
    case 'alw': S.always = S.always ? 0 : 1; $('#alw').classList.toggle('on', !!S.always); $('#alw').setAttribute('aria-pressed', !!S.always); break;
    case 'pal': S.pal = +id; S.acc = ''; apply(); renderSheet(); break;
    case 'up': target = id; $('#fi').click(); return;
    case 'rs': if (S.img[id]) { S.img[id] = 0; if (URLS[id]) { URL.revokeObjectURL(URLS[id]); delete URLS[id]; } IDB.del(id); } apply(); break;
    case 'replay': $('#sheet').hidden = true; intro(); return;
    case 'open': $('#intro').classList.add('out'); setTimeout(() => { $('#intro').hidden = true; }, 900); S.seen = 1; react('wave', 3500); break;
    case 'bks': { const c = Object.assign({}, S, {img:{}, gal:[]}); $('#bk').value = JSON.stringify(c); $('#bk').select(); try { navigator.clipboard.writeText($('#bk').value); toast('Backup copied'); } catch (x) {} break; }
    case 'bkr': try { const o = JSON.parse($('#bk').value); S = Object.assign(def(), o, {img:S.img, gal:S.gal}); S.day = ''; checkDay(); renderAll(); renderSheet(); $('#bk').value = 'Restored.'; } catch (x) { $('#bk').value = 'That backup could not be read.'; } break;
    case 'undo': if (UNDO) { UNDO(); UNDO = null; $('#toast').classList.remove('on'); } break;
    default: return;
  }
  persist();
});

$('#plans').addEventListener('click', e => { if (e.target.id === 'plans') $('#plans').hidden = true; });
$('#sheet').addEventListener('click', e => { if (e.target.id === 'sheet') $('#sheet').hidden = true; });
$('#fi').addEventListener('change', e => { const fs = [...e.target.files]; e.target.value = ''; if (fs.length) upload(fs); });
$('#newtd').addEventListener('keydown', e => { if (e.key === 'Enter') $('[data-a="tdadd"]').click(); });

document.addEventListener('input', e => {
  const t = e.target, D = t.dataset;
  if (D.el) { const s = S.sched.find(x => x.id === D.el); if (s) s.l = t.value; }
  else if (D.pi !== undefined) S.pri[D.pi] = t.value;
  else if (D.dl !== undefined) { const x = PV.draft && PV.draft.items[+D.dl]; if (x) x.l = t.value; }
  else if (t.id === 'pn') { if (PV.draft) PV.draft.n = t.value; }
  else if (t.id === 'win') S.win = t.value;
  else if (t.id === 'tom') S.tom = t.value;
  else if (t.id === 'ne') S.notes = t.value.split('\n').map(x => x.trim()).filter(Boolean);
  else if (t.id === 'nse') S.script = t.value;
  else if (D.cn !== undefined) { const [, c] = find(D.cn); if (c) c.n = t.value; }
  else if (t.id === 'sname') { const x = S.subj.find(y => y.id === S.sel); if (x) { x.n = t.value; const o = $('.sb.on .sbn'); if (o) o.textContent = t.value; } }
  else if (t.id === 'sn') { S.name = t.value; apply(); }
  else if (t.id === 'sh') { S.head = t.value; apply(); }
  else if (t.id === 's1') { S.g1 = t.value; apply(); }
  else if (t.id === 's2') { S.g2 = t.value; apply(); }
  else if (t.id === 'cc') { S.acc = t.value; apply(); }
  else return;
  persist();
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.dataset.dt !== undefined && PV.draft) { const p = t.value.split(':'), x = PV.draft.items[+t.dataset.dt]; if (x && p.length === 2) { x.m = +p[0] * 60 + +p[1]; PV.draft.items.sort((a, b) => a.m - b.m); PV.keep = 1; renderPlans(); } return; }
  if (t.dataset.wk !== undefined) {
    const d = +t.dataset.wk; if (t.value) S.week[d] = t.value; else delete S.week[d];
    const pl = t.value && planById(t.value);
    if (pl && d === new Date().getDay() && !Object.keys(S.done).length) { S.sched = fresh(pl.items()); renderSched(); toast(pl.n + ' is set for today'); } else toast(t.value ? 'Saved for ' + DN[d] : 'Cleared');
    persist(); return;
  }
  if (t.dataset.fill && t.tagName === 'SELECT') {
    const x = S.subj.find(y => y.id === t.value), i = $('#' + t.dataset.fill);
    if (x && i) { i.value = chLabel(x, 0); i.focus(); } t.value = ''; return;
  }
  if (t.dataset.et) { const p = t.value.split(':'), s = S.sched.find(x => x.id === t.dataset.et); if (s && p.length === 2) { s.m = +p[0] * 60 + +p[1]; renderSched(); persist(); } }
});

/* keep things correct while the app stays open */
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { flush(); return; }
  if (checkDay()) renderAll(); else { updateProgress(); }
  tTick();
});
setInterval(() => { if (!document.hidden && !temp && !vk && baseState() === 'idle' && S.tab === 'today' && Math.random() < .5) react(['think', 'wave', 'sip'][Math.floor(Math.random() * 3)], 2400); }, 22000);
setInterval(() => { if (!document.hidden) { if (checkDay()) renderAll(); else if (!EDIT.sched) updateProgress(); } }, 60000);

/* =====================================================================
   Start
   ===================================================================== */
document.body.appendChild($('#mascot')); /* docked in the corner, visible on every tab */
$('#mascot').innerHTML = skeletonSVG(); paintMascot();
renderAll();
showTab(S.tab || 'today');
loadImages();
if (!S.seen || S.always) intro(); else react('wave', 3500);
try { navigator.storage && navigator.storage.persist && navigator.storage.persist(); } catch (e) {}
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
window.__planner = {get state() { return S; }, flush};
})();
