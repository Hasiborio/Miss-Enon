# Daily Planner

Static app, no build step.

## Put it online (Netlify)
1. Go to app.netlify.com/drop
2. Drag this whole folder (unzipped) onto the page.
3. Send her the link it gives you.

## On her iPhone
Open the link in Safari -> Share -> Add to Home Screen. It then opens full-screen and works offline.

## Notes
- Data is saved on her phone (localStorage). Settings -> Backup can export/import it.
- `Sync` in app.js is the stub for future cloud sync.
